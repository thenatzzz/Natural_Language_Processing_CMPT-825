import pandas as pd
import numpy as np


fileName = 'finished_files/train.bin'

# with open(fileName, mode='rb') as file: # b is important -> binary
#     fileContent = file.read()
#     print(type(fileContent))
#     print(len(fileContent))
#    # print(fileContent)
# #
# with open(fileName, "rb") as binary_file:
#     # Read the whole file at once
#     data = binary_file.read()
#     print(len(data),type(data))
#     print(data[0])
